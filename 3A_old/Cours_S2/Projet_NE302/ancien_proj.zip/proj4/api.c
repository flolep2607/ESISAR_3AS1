
#include "api.h"
#include "parser.h"
#include "annexe.h"

char* mem;
char *no_go_zone;

int parseur(char* file_to_parse, int len) {
	puts("OK");
	
	mem=file_to_parse;
	no_go_zone=mem+len;
	
	int r = construire("HTTP-message");
	
	printf("Validité:");Truth(r);
	
	return r;
}
