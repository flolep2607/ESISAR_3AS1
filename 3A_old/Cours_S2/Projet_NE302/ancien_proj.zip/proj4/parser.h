#ifndef COLOR
	#include "color.h"
#endif
//Lib nécessaires
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
//Lib annexes (not used yet ?)
#include <sys/types.h>
#include <unistd.h>

//Constants
#define TRUE 1
#define FALSE 0
#define MAX_ITER 0xFFFF
#define MIN_ITER 0
#define MASK_OCTET 0xFF



// #define DEBUG
// #define DEBUG_MEMVIEW
#define DEBUG_IO_CONSTRUIRE



//Global var, used to point the file to parse
extern char* mem;
extern char *no_go_zone;

//main fonction that needs to be called from parser
int construire(char* module);