#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <sys/types.h>
#include <unistd.h>
#include "api.h"


//Color
#if 0
	#define RED    "\033[0;31m"
	#define BLUE   "\033[0;34m"
	#define GREEN  "\033[0;32m"
	#define YELLOW "\033[0;33m"
	#define MAGENTA "\e[0;35m"
	#define CYN "\e[0;36m"
	#define NC     "\033[0m"
#else
	#define RED    ""
	#define BLUE   ""
	#define GREEN  ""
	#define YELLOW ""
	#define MAGENTA ""
	#define CYN ""
	#define NC     ""
#endif

#define ABNF_RULES "mathis.abnf"

#define TRUE 1
#define FALSE 0
#define MAX_ITER 0xFFFF
#define MIN_ITER 0
#define MASK_OCTET 0xFF

// #define DEBUG
// #define DEBUG_MEMVIEW
// #define DEBUG_IO_CONSTRUIRE

char* mem;
char *no_go_zone;

int construire(char* module);

/*
typedef struct node {
    char* tag;
    char* value; // pointer to the first char of the value
    int len;  // number of char starting from pointer value
    struct node *child; // pointer to the first child or NULL
    struct node *brother; // pointer to the next brother node or NULL
} node;

node *generateNodes(char* value, int len, char nextDelim[]) {
    node *node = malloc(sizeof(node));
    if (node == NULL) {
        perror("malloc failed");
        exit(1);
    }
    //node->tag     calculated
    node->len = len;
    node->value = value;

    return node;
}
*/
void Truth(int b){
	if(b) printf(GREEN"TRUE\n"NC); else printf(RED"FALSE\n"NC);
}

int parseur(char* file_to_parse, int len) {
	puts("OK");
	mem=file_to_parse;
	no_go_zone=mem+len;
	int r = construire("HTTP-message");
	printf("Validité:");Truth(r);
	return r;
}

/*
char * content(char* str){
	printf("%s\n",str);
	char* s = "\"start\" %x56.4B %x69  %x01-99 2* ( %x70 / %x75 ) ";
	char* c = (char*)malloc(strlen(s)+1);
    strcpy(c,s);//a com
    
	return c;
}
*/

char * content(char* st){
    int len = strlen(st);
    FILE* file_abnf = fopen(ABNF_RULES,"r");
    if(file_abnf == NULL) { 
        perror("Probleme ouverture gram.abnf"); 
        exit(1); 
    }

    char curr_char = 0;
    int i = 0;
    char* c = (char*)malloc(1000*sizeof(char));    //Remplacer 1000 par une constante MAX
    for (int i=0; i<1000; i++) c[i]='\0';
    while(i<len && curr_char != EOF){
        i = 0;
        curr_char = getc(file_abnf);
        if (curr_char != st[i]){
            while (curr_char != '\n' && curr_char != EOF){
                curr_char = getc(file_abnf);
            }
        }
        while(curr_char == st[i] && i < len && curr_char != EOF){    //tant que le début de la ligne correspond à str
            curr_char = getc(file_abnf);
            i++;
        }
        if (i==len){
            curr_char = getc(file_abnf);
            if (curr_char != '=') i = 0;
        }
    }
    
    if (curr_char != EOF){
            getc(file_abnf);
            curr_char = getc(file_abnf);    //espace
            i = 0;
            while (curr_char != '\n' && curr_char != EOF){    //Copie dans c jusqu'au '\n'
                c[i] = curr_char;
                i++;
                curr_char = getc(file_abnf);
            }
            c[i]='\0';
    }
    else{
		perror("ERR");
        printf("Pas trouvé :%s\n", st);
    }
    fclose(file_abnf);
    return c;
}


int nocase_memcomp(char* s, char* d, int l){
    int i = 0;
    while(i<l && (s[i]==d[i] || (isalpha(s[i]) && isalpha(d[i]) && s[i]%32==d[i]%32))){
        i++;
    }
    return (i==l);
}

int distance_from(char * st,char * end, char a){
	// printf("\t\t\t\t\t>%s\n",st);
	int res=0;
	while(st<end && *st != a && *st != '\0') {res++;st++;}
	return res;
}





int algo0(char* str, int len){ //if error return 1 else ret 0
	char *ptr, *end;
	int Res = TRUE;
	ptr = str;
	end = str + len;
	#ifdef DEBUG
		printf(MAGENTA"Entree dans algo:[");
		fflush(stdout);
		write(STDOUT_FILENO, str,len);
		puts("]"NC);
	#endif
	
	while (ptr < end && *ptr != '\0' && mem <no_go_zone){
		#ifdef DEBUG
			printf("Current scan: [%c]\n",*ptr);
		#endif
		
/*----*/if(isalpha(*ptr)){/* ETAPE 1 ------------- */
		#ifdef DEBUG
		printf("Matched a letter !\n");
		#endif
		char * debut = ptr;
		while( !isspace(*++ptr)) ;
		char command[50];
		int longueur=(ptr-debut);
		memcpy(command,debut,longueur);
		command[longueur]='\0';
		#ifdef DEBUG
			printf(BLUE "cmd_> %s\n"NC" ",command);
		#endif
		char* backup=mem;
/** ####### APPEL RECURSIF ##############################*/
/** #####*/	Res = construire(command);/**####*/
/** #####################################################*/
		if(!Res)mem=backup;
		#ifdef DEBUG
			printf("Res %s: ",command); Truth(Res);
		#endif
		}
		else
/*----*/if(isdigit(*ptr) || *ptr=='*'){/* ETAPE 3  */
			int x,y;
			y=MAX_ITER;
			x=MIN_ITER;
			
			if (isdigit(*ptr)) {
				#ifdef DEBUG
				printf("Matched a digit\n");
				#endif
				sscanf(ptr,"%d*%d", &x, &y);
				if (*(ptr+1)!='*')
					y = x;
			} else if (*ptr=='*'){
				#ifdef DEBUG
				printf("Matched a '*'\n");
				#endif
				sscanf(ptr,"* %d", &y);
			}
			while(!isspace(*++ptr)){;}
			while(isspace(*++ptr)){;}
			#ifdef DEBUG
				printf(BLUE"\tnext:[%c]\n"NC,*ptr);
				printf("\tx:%d / y:%d\n",x,y);
			#endif
			
			char* pointeur_cool = ptr;
			
			if(*ptr=='('){
				//Etape n°33
				pointeur_cool++;//si pointeur_cool -> '(' on l'incr pour qu'il pointe sur le vrai debut de la chaine
				while(ptr < end && *ptr != ')') ptr++;
			} else {
				//Etape n°32
				while(!isspace(*++ptr));
			}
			char* backup=mem;
			char* backup2=mem;//si on a valider moins de fois que x
			int i=0;
			while(i<y && Res){
				#ifdef DEBUG_MEMVIEW
				printf(CYN"tmp:%c\n"NC,*mem);
				#endif
				#ifdef DEBUG
				printf(RED"Call>_algo0("NC);fflush(stdout);
				write(STDOUT_FILENO, pointeur_cool,ptr-pointeur_cool);
				printf(RED")\n"NC);
				#endif
				Res = algo0(pointeur_cool,ptr-pointeur_cool);
				if(Res) backup = mem;
				i+=Res;
			} 
			 mem = backup;
			Res = (i>=x) && (i<=y);
			if(!Res)mem=backup2;
			#ifdef DEBUG
				printf("\texit loop with i=%d\n",i);
				printf("Res: "); Truth(Res);
			#endif
		}
		else
/*----*/if(*ptr=='%'){/* ETAPE 4 ----------------- */
			#ifdef DEBUG
			printf("Matched '%%' !\n");
			#endif
			ptr++;
			assert(*ptr=='x');
			#ifdef DEBUG
			puts("\tx is there, good.");
			#endif
			
			if(*(ptr+3)=='.'){
				/*Si: %xHH.HH.HH...*/
				#ifdef DEBUG
				puts("\tdetected pattern: HH.HH...");
				#endif
				int nb;
				char* mem_bak = mem;
				while(!isspace(*ptr) && Res && mem <no_go_zone){
					sscanf(ptr+1,"%x",&nb);
					#ifdef DEBUG_MEMVIEW
						printf("\t\twhl ptr:%c\n",*(ptr));
						printf("\t\tmem: %c %x | ptr: %c %x\n",*mem,*mem,nb,nb);
					#endif
					Res = (*mem==nb);
					mem+=Res; ptr+=3;
				}
				if(!Res)mem=mem_bak;
			} else {
				/*Si: %xHH-HH ou %xHH */
				#ifdef DEBUG
				printf("\tdetected pattern: HH-HH\n");
				#endif
				u_int8_t h1,h2;
				sscanf(ptr+1,"%hhx-%hhx",&h1,&h2);
				
				if(*(ptr+3)=='-') ptr+=6;
				else { ptr+=3; h2=h1; }
				#ifdef DEBUG_MEMVIEW
					printf("\t\th1:%x h2:%x | mem:%x %c\n",h1,h2,*mem,*mem);
				#endif
				Res = ((*mem&MASK_OCTET) >= h1) && ((*mem&MASK_OCTET) <= h2);
				mem+=Res;
			}
			#ifdef DEBUG
				printf("Res: "); Truth(Res);
			#endif
		}
		else
/*----*/if(*ptr=='"'){/* ETAPE 5 ----------------- */
			#ifdef DEBUG
				printf("Matched '\"'\n");
			#endif
			ptr++;
			int longueur = distance_from(ptr,end,'"');
			if(mem+longueur >= no_go_zone)
				Res = FALSE;
			else
				Res = nocase_memcomp(ptr,mem,longueur);
			#ifdef DEBUG_MEMVIEW
			printf("\t["); fflush(stdout);
			write(STDOUT_FILENO, ptr,longueur);
			printf("]\n\t["); fflush(stdout);
			write(STDOUT_FILENO, mem,longueur); puts("]");
			#endif
			mem+=longueur*Res;
			ptr+=longueur+1;
			#ifdef DEBUG
				printf("Res: "); Truth(Res);
			#endif
		}
		else
/*----*/if(*ptr=='('){/* ETAPE 9 ----------------- */
			#ifdef DEBUG
				printf("Matched '('\n");
			#endif
			ptr++;
			char* debut=ptr;
			int parenthesis=0;
			int crochet=0;
			while(ptr < end && !( *ptr == ')' && parenthesis==0 && crochet==0)) {
				if(*ptr=='"') ptr += distance_from(ptr+1,end,'"')+2;
				parenthesis+=(*ptr=='(');
				crochet+=((*ptr=='['));
				parenthesis-=((*ptr==')'));
				crochet-=((*ptr==']'));
				ptr++;
			}
			// printf("stop at:%c,next:%c\n",*ptr,*(ptr+1));
			Res = algo0(debut,ptr-debut);
			#ifdef DEBUG
				printf("Out of parenthesis; current:'%c'\n",*ptr);
			#endif
			 ptr++;
		}
		else
/*----*/if(*ptr=='['){/* ETAPE 69 ---------------- */
			char* debut = ++ptr;
			int parenthesis=0;
			int crochet=0;
			while(ptr < end && ( *ptr != ']' || parenthesis || crochet)) {
				if(*ptr=='"') ptr += distance_from(ptr+1,end,'"')+2;
				parenthesis+=((*ptr=='('));
				crochet+=((*ptr=='['));
				parenthesis-=((*ptr==')'));
				crochet-=((*ptr==']'));
				ptr++;
			}
			
			char* backup=mem;
			char* backup2=mem;
			int i=0;
			int x=0;
			int y=1;
			while(i<y && Res){
				#ifdef DEBUG_MEMVIEW
				printf(CYN"tmp:%c\n"NC,*mem);
				#endif
				#ifdef DEBUG
				printf(RED"Call>_algo0("NC);fflush(stdout);
				write(STDOUT_FILENO, debut,ptr-debut);
				printf(RED")\n"NC);
				#endif
				Res = algo0(debut,ptr-debut);
				if(Res) backup = mem;
				i+=Res;
			} 
			mem = backup;
			Res = (i>=x) && (i<=y);
			if(!Res)mem=backup2;
			#ifdef DEBUG
				printf("\texit loop with i=%d\n",i);
				printf("Res: "); Truth(Res);
			#endif
		}
		else
		if(*ptr==')'){
			printf("ptr:%s\n",ptr-20);
			printf(YELLOW"str:(%s)\n"NC,str);
			perror("Parsing error on parenthesis");
			exit(1);
		}
		
/* ---- ETAPE 2 ---------------------------------- */
		{
			if (*ptr=='/') {
				if(Res){
					//WHILE EXIT (return Res)
					ptr = end-1; 
				}else{
					Res = TRUE;
				}
			} else {
				if(!Res){
					//Step n23 Goto '/'
					int parenthesis=0;
					int crochet=0;
					while(ptr < end && ( *ptr != '/' || parenthesis || crochet)) {
						if(*ptr=='"') ptr += distance_from(ptr+1,end,'"')+2;
						parenthesis+=((*ptr=='('));
						crochet+=((*ptr=='['));
						parenthesis-=((*ptr==')'));
						crochet-=((*ptr==']'));
						ptr++;
					}
					if(ptr < end && *ptr=='/') Res = TRUE;
				}
			}
		}
		ptr++;
	}
	if(mem>no_go_zone){
		perror("mem pointer out of range");
		Res = FALSE;
	}
	#ifdef DEBUG
		printf("Return Res:"); Truth(Res);
	#endif
	
	return Res;
}

int construire(char* module){
	int Valid;
	
	char * str = content( module );
	#ifdef DEBUG_IO_CONSTRUIRE
		printf(YELLOW"CONSTRUIRE %s\n"NC,module);
		printf(YELLOW"str:|%s|\n"NC,str);
	#endif
	char* debut_value = mem;
	/* Procédure d'appel principale */
		Valid = algo0(str,strlen(str));
		
	#ifdef DEBUG_IO_CONSTRUIRE
		if (Valid) printf(GREEN"Nice"NC" (exitting:%s)\n",module);
		else printf(RED"prout prout"NC" (exitting:%s)\n",module);
		// write(STDOUT_FILENO,debut_value,mem-debut_value); printf("[EOL]\n");
		write(STDOUT_FILENO,mem,20); printf("[EOL]\n");
	#endif

	free(str);
	
	return Valid; // return 1 si valide
	
}