#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <sys/types.h>
#include <unistd.h>
#include "api.h"

#define RED    "\033[0;31m"
#define BLUE   "\033[0;34m"
#define GREEN  "\033[0;32m"
#define YELLOW "\033[0;33m"
#define MAGENTA "\e[0;35m"
#define CYN "\e[0;36m"
#define NC     "\033[0m"

#define TRUE 1
#define FALSE 0
#define MAX_ITER 0xFFFF
#define MIN_ITER 0

#define IMMEDIATE_EXIT 69

char* mem;
char *no_go_zone;

int construire(char* module);

/*
typedef struct node {
    char* tag;
    char* value; // pointer to the first char of the value
    int len;  // number of char starting from pointer value
    struct node *child; // pointer to the first child or NULL
    struct node *brother; // pointer to the next brother node or NULL
} node;

node *generateNodes(char* value, int len, char nextDelim[]) {
    node *node = malloc(sizeof(node));
    if (node == NULL) {
        perror("malloc failed");
        exit(1);
    }
    //node->tag     calculated
    node->len = len;
    node->value = value;

    return node;
}
*/
void Truth(int b){
	if(b) printf(GREEN"TRUE\n"NC); else printf(RED"FALSE\n"NC);
}
int parseur(char* file_to_parse, int len) {
	puts("OK");
	mem=file_to_parse;
	no_go_zone=mem+len;
	return construire("mess");
	
}
/*
char * content(char* str){
	printf("%s\n",str);
	char* s = "\"start\" %x56.4B %x69  %x01-99 2*  ( %x70 / %x75 ) ";
	char* c = (char*)malloc(strlen(s)+1);
    strcpy(c,s);//a com
    
	return c;
}
*/

char * content(char* str){
	int len = strlen(str);
	FILE* file_abnf = fopen("gram.abnf","r");
	if(file_abnf == NULL) { 
		perror("Probleme ouverture gram.abnf"); 
		exit(1); 
	}

	char curr_char = 0;
	int i = 0;
    char* c = (char*)malloc(100*sizeof(char));	//Remplacer 100 par une constante MAX
	c[0]='\0';
	while(i<len && curr_char != EOF){
		i = 0;
		curr_char = getc(file_abnf);
		if (curr_char != str[i]){
			while (curr_char != '\n' && curr_char != EOF){
				curr_char = getc(file_abnf);
			}
		}
		while(curr_char == str[i] && i < len && curr_char != EOF){	//tant que le début de la ligne correspond à str
			curr_char = getc(file_abnf);
			i++;
		}
		
	}
	
	if (curr_char != EOF){
		getc(file_abnf);	//espace
		getc(file_abnf);	//'='
		curr_char = getc(file_abnf);	//espace
		i = 0;
		while (curr_char != '\n' && curr_char != EOF){	//Copie dans c jusqu'au '\n'
			c[i] = curr_char;
			i++;
			curr_char = getc(file_abnf);
		}
		c[i]='\0';
	}
	else{
		printf("Pas trouvé =(\n");
	}
	fclose(file_abnf);
	return c;
}



int distance_from(char * str, char a){
	int res=0;
	while(*str != a && *str != '\0') {res++;str++;}
	return res;
}

int construire(char* module){
	char *str, *ptr, *end;
	int Valid=1;
	int algo0(int a){ //if error return 1 else ret 0
		int Res = TRUE;
		char* mem_bak = mem;
		
		printf(MAGENTA"ENTREE DANS ALGO AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\n"NC);
		printf(":%c:-",*ptr);
		/*Etape0*/
		while( isspace(*ptr) ) ptr++;
		printf("[%c]\n",*ptr);
		if (isalpha(*ptr)){ //E1
/*--------- Etape1 ------------------------------------------*/
			printf("It's a letter !\n");
			char * ptr_bak = ptr;
			while( !isspace(*++ptr) );
			char command[50];
			int len=(ptr-ptr_bak);
			memcpy(command,ptr_bak,len);
			command[len]='\0';
			printf(BLUE "cmd_> %s\n"NC" ",command);
/** ####### APPEL RECURSIF ##############################*/
/** #####*/	Res = construire(command);/**####*/
/** #####################################################*/
		} else
		if (isdigit(*ptr) || *ptr=='*'){//E3
/*--------- Etape3 ------------------------------------------*/
			int x,y;
			y=MAX_ITER;
			x=MIN_ITER;
			if (isdigit(*ptr)) {
				printf( RED "It's a digit !\n"NC);
				sscanf(ptr,"%d*%d", &x, &y);
				if (*(ptr+1)!='*')
					y = x;
			} else if (*ptr=='*'){
				printf(RED"It's a '*' !\n"NC);
				sscanf(ptr,"* %d", &y);
			}
			while(!isspace(*++ptr));
			printf("x:%d / y:%d\n",x,y);
			char * bak = ptr;
			int i=0;
			while(i<=y && Res){
				ptr = bak;
				mem_bak=mem;
				
				Res = algo0(IMMEDIATE_EXIT);
				i+=Res;
			} 
			mem=mem_bak;
			Res = (i>=x) && (i<=y);
			printf(CYN"exit boucle with\ntmp:[%c] ptr:[%c] i:%d"NC,*mem_bak,*(ptr),i);
/*--------- Fin Etape 3 -------------------------------------*/
		}		else
		if (*ptr=='('){ //E(
/*--------- Boucle parenthese -------------------------------*/
			printf("It's a '(' !\n");
			a = 0;
			ptr++;
			Res = algo0(0);
			
		} else
		if (*ptr=='"'){ //E5
/*--------- Etape5 ------------------------------------------*/
			printf("It's a '\"' !\n");
			ptr++;
			int len = distance_from(ptr,'"');
			Res = (0==memcmp(ptr,mem,len));
			write(STDOUT_FILENO, ptr,len); puts("");
			write(STDOUT_FILENO, mem,len); puts("");
				mem+=len;
				ptr+=len+1;
		} else
		if (*ptr=='%'){ //E4
/*--------- Etape4 ------------------------------------------*/
			printf("It's a '%%' !\n");
			ptr++;
			assert(*ptr=='x'); puts("x is there, good.");
			//ptr++;
			if(*(ptr+3)=='.'){
				/*Si: %xHH.HH.HH...*/
				puts("detected pattern: HH.HH...");
				int nb;
				printf("current:%s\n",ptr);
				while(!isspace(*ptr) && Res){
														printf("whl ptr:%c\n",*(ptr));
					sscanf(ptr+1,"%x",&nb);
														printf("mem: %c %x | ptr: %c %x\n",*mem,*mem,nb,nb);
					Res = (*mem==nb);
					mem+=Res; ptr+=3;
				}
			} else {
				/*Si: %xHH-HH ou %xHH */
				printf("detected pattern: HH-HH\n");
				int h1,h2;
				sscanf(ptr+1,"%x-%x",&h1,&h2);
				if(*(ptr+3)=='-') ptr+=6;
				else { ptr+=3; h2=h1; }
				printf("h1:%x h2:%x | mem:%x %c\n",h1,h2,*mem,*mem);
				Res = (*mem >= h1) && (*mem <= h2);
				//printf("Res: ",Res); Truth(Res);
				mem+=Res;
			}
/*--------- Fin Etape 4 -------------------------------------*/
		}
		else if (*ptr=='/') {
			printf("Return:");Truth(Res);
			return Res;
		}
		else { //E'\0' ou E')'
			/*EXIT*/ if(*ptr==')') printf(YELLOW"EXIT BOUCLE\n"NC);
			ptr++;
			if(*(ptr-1)=='/' && !Res)
				return algo0(0);
			return TRUE;
		}
		
		printf("ptr:%s\n",ptr);
/*----- Etape2 ----------------------------------------------*/
		while(isspace(*ptr))ptr++;
		if(a==IMMEDIATE_EXIT) {
			printf(RED"IMEDIATE EXIT\n"NC);
			return Res;
		}
		if (*ptr=='/') {
			printf("Return:");Truth(Res);
			if(!Res) { ptr++; Res=algo0(0);}
			return Res;
		}else{
			printf("algo0-Callback: ");
			Truth(Res);
			Res &= algo0(0);
			printf("return from & at *:%s\n",ptr);
			// if (*ptr=='/') {
				
			// ptr++;
			// if (Res) {
				// mem_bak = mem;
				// algo0(0);
				// mem = mem_bak;
			// } else {
				// mem = mem_bak;
				// Res = algo0(0);
			// }
			// }
			ptr++;
			return Res;
		}
/*----- Fin Etape 2 -----------------------------------------*/
	/* ¤¤¤¤¤¤ RETURN ¤¤¤¤¤¤ 
		printf("algo0-Exit: ");
		Truth(Res);
		return Res; */
		return TRUE;
	}
	
	
	str = content( module );
	printf(YELLOW"str:%s\n"NC,str);
	ptr = str;
	end = str + strlen(str);
	
	/* Procédure d'appel principale */
	//while( ptr<end && Valid )
		Valid = algo0(0);
	if (Valid) puts(GREEN"Nice"NC" (exitting construire)");
	
	free(str);
	
	return Valid; // return 1 si valide
	
}