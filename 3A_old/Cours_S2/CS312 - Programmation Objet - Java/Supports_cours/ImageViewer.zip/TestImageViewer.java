
public class TestImageViewer {

	public static void main(String argv[]) {
		ImageViewer iv = new ImageViewer();
	}
}
