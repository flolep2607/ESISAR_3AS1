#include <stdio.h>
#include "interaction.h"
#include "callbacks.h"

void interaction1(){
    int choix;
    printf("interaction1\n");
    while (1){
        scanf("%d", &choix);
        switch (choix){
        case 1 : f1(); break;
        case 2 : f2(); break;

        case -1 : return;
        }
    }
}



void interaction3(){
    int choix;
    void (*f[N])(void);
    printf("interaction2\n");
    f[0] = f1;
    f[1] = f2;
    while (1){
        scanf("%d", &choix);
        if (choix < 1 || choix > 2 ) return;
        f[choix-1]();
    }
}

void interaction4(){
    int choix;
    int i;
    void (*f[N])(int);
    printf("interaction4\n");
    f[0] = f3;
    f[1] = f4;
    while (1){
        printf("Choix :");
        scanf("%d", &choix);
        if (choix < 1 || choix > 2 ) return;
        printf("parametre :");
        scanf("%d", &i);
        f[choix-1](i);
    }
}



