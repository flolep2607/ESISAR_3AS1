#include <stdio.h>


void f1(){
 printf("f1\n");
}

void f2(){
 printf("f2\n");
}

void f3(int c){
 printf("f3 %d\n", c);
}

void f4(int c){
 printf("f4 %d%d\n", c, c);
}
