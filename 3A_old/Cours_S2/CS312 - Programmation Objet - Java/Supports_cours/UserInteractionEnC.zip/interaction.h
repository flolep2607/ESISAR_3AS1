#define N 10

void interaction1();
void interaction2();
void interaction3();
void interaction4();

