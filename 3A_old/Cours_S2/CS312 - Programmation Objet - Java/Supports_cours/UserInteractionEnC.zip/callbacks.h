void f1();
void f2();
void f3();
void f4();
