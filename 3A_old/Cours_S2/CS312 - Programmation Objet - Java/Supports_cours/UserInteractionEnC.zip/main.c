#include <stdio.h>
#include <stdlib.h>

#include "interaction.h"

int main()
{
    interaction1();
    interaction3();
    interaction4();
    return 0;
}
