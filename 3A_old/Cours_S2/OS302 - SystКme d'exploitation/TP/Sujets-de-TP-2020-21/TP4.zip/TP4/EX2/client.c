
#include "calcul.h"

#include <assert.h>


int main(int argc, char const *argv[])
{
	int snd_msg_id,rcv_msg_id;
	struct msg_struct msg;
	pid_t pid = getpid();

	if (argc != 2) {
		printf("Usage: %s \"text\"\n", argv[0]);
		return EXIT_FAILURE;
	}

	/* Il faut que la chaine de charactere fasse moins de MAX characteres */
	assert(strlen(argv[1])<MAX);


	/* ATTENTION : la file de messages doit avoir ete creee par le serveur. Il
	 * faudrait tester la valeur de retour (msg_id) pour verifier que cette
	 * creation a bien eu lieu. */

	key_t snd_key = ftok(FICHIER_CLE, 1) ;
	key_t rcv_key = ftok(FICHIER_CLE, 0) ;
	
	snd_msg_id = msgget(snd_key, 0);
	rcv_msg_id = msgget(rcv_key, 0);

	if(snd_msg_id == -1) {
		perror("snd_msg_id error");
		exit(1);
	}
	if(rcv_msg_id == -1) {
		perror("rcv_msg_id error");
		exit(1);
	}
	
	
	
	printf("CLIENT %d: preparation du message contenant le text suivant:\
		   	%s\n",pid,msg.text);

	/* On prepare un message de type 1 à envoyer au serveur avec les
	 * informations necessaires */
	msg.type=1;
	msg.sender_pid=pid;
	strcpy(msg.text,argv[1]);
	
	/* envoi du message */
	msgsnd(snd_msg_id, &msg, sizeof(struct msg_struct)-sizeof(long), 0);


	/* reception de la reponse */
	msgrcv(rcv_msg_id, &msg, sizeof(struct msg_struct)-sizeof(long), pid, 0);
	printf("CLIENT: resultat recu depuis le serveur %d : %s\n",
	msg.sender_pid, msg.text);
	return EXIT_SUCCESS;
}
