#ifndef __CALCUL_H__
#define __CALCUL_H__

//Common libs
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <string.h>

//Fichier cle pour ftok()
#define FICHIER_CLE "cle"


//Maximum de char dans text[]
#define MAX 100

struct msg_struct {
    long type;
    /* A COMPLETER */
    pid_t sender_pid;
    char text[MAX];
};

#endif /* __CALCUL_H__ */
