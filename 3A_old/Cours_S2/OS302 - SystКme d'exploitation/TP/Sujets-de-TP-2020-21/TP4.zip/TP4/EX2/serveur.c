
#include "calcul.h"

#include <sys/stat.h>
#include <signal.h>
#include <ctype.h>


#define TAILLE_MSG sizeof(struct msg_struct)-sizeof(long)

int msg_id;

/* Supprime la file de message et exit */
void raz_msg(int signal) {
	printf("Suppression de la file de message!\n");
	msgctl(msg_id, IPC_RMID, NULL);
	exit(1);
}

/* Convert a string to upper case */
void convert(char * str){
	int i=0;
	while(str[i]){
		str[i]=toupper(str[i]);
		i++;
	}
}

int main (int argc, char const *argv[])
{
	struct msg_struct msg;
	int snd_msg_id, rcv_msg_id;
	int i_sig;
	pid_t pid = getpid();

	/* liberer la zone de messages sur reception de n'importe quel signal */

	for (i_sig = 0 ; i_sig < NSIG ; i_sig++) {
		signal(i_sig,raz_msg); 
	}
	

	key_t snd_key = ftok(FICHIER_CLE, 0) ;
	key_t rcv_key = ftok(FICHIER_CLE, 1) ;
	
	/* On peut rajouter IPC_EXCL: fail if the key specified has an associated ID*/
	/* https://www.gnu.org/software/libc/manual/html_node/Permission-Bits.html */
	/* S_IRUSR: owner can read  (0400) */
	/* S_IWUSR: owner can write (0200) */ /* inclus dans <sys/stat.h>*/
	/* S_IROTH: other can read  (0004) */
	/* S_IWOTH: other can write (0002) */
	snd_msg_id = msgget(snd_key, IPC_CREAT | S_IWUSR | S_IROTH );
	rcv_msg_id = msgget(rcv_key, IPC_CREAT | S_IRUSR | S_IWOTH );

	if(snd_msg_id == -1) {
		perror("snd_msg_id error");
		exit(1);
	}
	if(rcv_msg_id == -1) {
		perror("rcv_msg_id error");
		exit(1);
	}
	
	
	printf("SERVEUR: pret!\n");

	while (1 == 1) {
		/* reception */
		/*                  1 = msg_type  0 = pas de flags   */
		if ( msgrcv(rcv_msg_id, &msg, TAILLE_MSG, 1, 0) == -1 ) {
			perror("error during msgrcv");
			exit(1);
		}
		
		printf("SERVEUR: reception d'une requete de la part de: %d\n",msg.sender_pid);
		
		/* preparation de la reponse */
		convert(msg.text);
		msg.type=msg.sender_pid;
		msg.sender_pid=pid;
		
		/* envoi de la reponse */
		printf("SERVEUR: envoie de la réponse: %s\n", msg.text);
		msgsnd(snd_msg_id, &msg, TAILLE_MSG, 0);
		
		/* On "@" recption: exit */
		if(msg.text[0]=='@')
			raz_msg(SIGINT);
	}
	return EXIT_SUCCESS;
}

