#ifndef __CALCUL_H__
#define __CALCUL_H__


struct msg_struct {
    long type;
    /* A COMPLETER */
    pid_t sender_pid;
    union {
	int operande1;
	int resultat;
    };
    int operande2;
    char operateur;
};

#endif /* __CALCUL_H__ */
