
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>

#include "calcul.h"

#define FICHIER_CLE "cle"

int main(int argc, char const *argv[])
{
	int msg_id;
	struct msg_struct msg;

	if (argc != 4) {
		printf("Usage: %s operande1 {+|-|*|/} operande2\n", argv[0]);
		return EXIT_FAILURE;
	}

	/* il faut eviter la division par zero */
	/* A COMPLETER */
	int a=atoi(argv[1]);
	char op=argv[2][0];
	int b=atoi(argv[3]);
	pid_t pid = getpid();
	/* ATTENTION : la file de messages doit avoir ete creee par le serveur. Il
	 * faudrait tester la valeur de retour (msg_id) pour verifier que cette
	 * creation a bien eu lieu. */

	key_t ma_cle = ftok(FICHIER_CLE, 0) ;

	// flag=0 car la queu à déjà été créée
	msg_id = msgget(ma_cle, 0);
	if(msg_id == -1) {
		perror("msg_id error");
		exit(1);
	}
	
	
	printf("CLIENT %d: preparation du message contenant l'operation suivante:\
		   	%d %c %d\n", pid, a, op, b);

	/* On prepare un message de type 1 à envoyer au serveur avec les
	 * informations necessaires */
	msg.operande1=a; msg.operande2=b;
	msg.operateur=op;
	msg.type=1;
	msg.sender_pid=pid;
	
	
	/* envoi du message */

	msgsnd(msg_id, &msg, sizeof(struct msg_struct)-sizeof(long), 0);

	/* reception de la reponse */

	msgrcv(msg_id, &msg, sizeof(struct msg_struct)-sizeof(long), pid, 0);
	printf("CLIENT: resultat recu depuis le serveur %d : %d\n",
	msg.sender_pid, msg.resultat);
	return EXIT_SUCCESS;
}
