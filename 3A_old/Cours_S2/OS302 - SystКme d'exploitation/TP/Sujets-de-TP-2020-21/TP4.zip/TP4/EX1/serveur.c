
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>

#include "calcul.h"

#define FICHIER_CLE "cle"


int msg_id;


void raz_msg(int signal) {
	printf("Suppression de la file de message!\n");
	msgctl(msg_id, IPC_RMID, NULL);
	exit(1);
}


int compute(struct msg_struct msg){
	int resultat=0;
	switch(msg.operateur){
		case '+':
		    resultat = msg.operande1 + msg.operande2;
		break;
		case '-':
		    resultat = msg.operande1 - msg.operande2;
		break;
		case '*':
			resultat = msg.operande1 * msg.operande2;
		break;
		case '/':
			resultat = msg.operande1 / msg.operande2;
		break;
	}
	return resultat;
}

int main (int argc, char const *argv[])
{
	struct msg_struct msg;
	int i_sig;
	//int result;
	pid_t pid = getpid();

	/* liberer la zone de messages sur reception de n'importe quel signal */

	for (i_sig = 0 ; i_sig < NSIG ; i_sig++) {
		signal(i_sig,raz_msg); 
	}

	key_t ma_cle = ftok(FICHIER_CLE, 0) ;
	
	msg_id = msgget(ma_cle, IPC_CREAT | 0600);

	if(msg_id == -1) {
		perror("msg_id error");
		exit(1);
	} else
		printf("SERVEUR: pret!\n");

	while (1 == 1) {
		/* reception */
		/*                  1 = msg_type  0 = pas de flags   */
		if ( msgrcv(msg_id, &msg, sizeof(struct msg_struct)-sizeof(long), 1, 0) == -1 ) {
			perror("error during msgrcv");
			exit(1);
		}
		printf("SERVEUR: reception d'une requete de la part de: %d\n",msg.sender_pid);
		
		/* preparation de la reponse */
		msg.resultat =  compute(msg);
		msg.type = msg.sender_pid;
		msg.sender_pid=pid;
		
		/* envoi de la reponse */
		printf("SERVEUR: envoie de la réponse: %d\n", msg.resultat);
		msgsnd(msg_id, &msg, sizeof(struct msg_struct)-sizeof(long), 0);
	}
	return EXIT_SUCCESS;
}

