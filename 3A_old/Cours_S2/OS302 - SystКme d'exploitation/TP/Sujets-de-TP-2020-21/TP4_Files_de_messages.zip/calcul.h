#ifndef __CALCUL_H__
#define __CALCUL_H__


struct msg_struct {
    long type;
    /* A COMPLETER */
};

#endif /* __CALCUL_H__ */
