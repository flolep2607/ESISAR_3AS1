#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <wait.h>
#include "func1.h"

/** ne doit pas être modifié **/

int main (void)
{
  pid_t mes_fils[NF];
  int status;

  mat1=allocate_matrice(DM,DM);
  mat2=allocate_matrice(DM,DM);
  matdiff=allocate_matrice(DM,DM);

  lecture_matrice();
  creation(mes_fils);
  resultat(mes_fils, matdiff);
  affiche_matrice(matdiff,DM,DM);

return 0;
}
