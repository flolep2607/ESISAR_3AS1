#include <stdio.h>
#include <unistd.h>
#include <stdlib.h> 
#include <wait.h>
#include "func1.h"

void lecture_matrice(void)
{ // Lit 2 matrices d’éléments entiers et de dimensions 2 par 2 – A compléter
printf("Lecture matrices \n");
}

int difference(int v1, int v2)
{ //renvoie la différence des 2 entiers transmis en arguments – A compléter
printf("Calcul différence élémentaire\n");
 
}

void creation(pid_t tab[NF])
{/* 
Permet de créer 4 processus fils dont les PID sont stockés dans le tableau tab. Chaque processus fils effectue une différence élémentaire :
-	Le fils 1 calcule la différence de mat1[0][0] et mat2[0][0]
-	Le fils 2 calcule la différence de mat1[0][1] et mat2[0][1]
-	Le fils 3 calcule la différence de mat1[1][0] et mat2[1][0]
-	Le fils 4 calcule la différence de mat1[1][1] et mat2[1][1]
Chaque processus fils transmet le résultat de son calcul au processus père au moyen de la fonction exit(). A compléter */

printf("Création fils \n");
}

void resultat(pid_t tab[NF], int **matdiff) 
{/* 
Permet au processus père de se synchroniser sur la terminaison de ses 4 fils dont les PID sont transmis dans le paramètre tab[NF]. Le père récupère le résultat de chaque fils et construit la matrice résultat dans le paramètre matdiff. A compléter. */

printf("résultats fils \n");
}

int **allocate_matrice( int i, int j)
{
  int **mat;
  int k;

  mat = malloc(i*sizeof(*mat));
  for (k=0; k<i; k++){
    mat[k] = malloc(j*sizeof(*mat[k]));
  }
  return mat;
}

void affiche_matrice(int** mat, int i, int j)
{int k, l;

  for (k=0; k<i; k++){
    for (l=0; l<j; l++){
      printf("%d \t", mat[k][l]);
    }
    printf("\n");
  }
}

void free_matrice(int** mat, int i)
{int k;

  for (k=0; k<i; k++)
  {
    free(mat[k]);
  }
  free(mat);
}

void free_matrices(){
  free_matrice(mat1,DM);
  free_matrice(mat2,DM);
  free_matrice(matdiff,DM);
}
