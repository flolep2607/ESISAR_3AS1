var searchData=
[
  ['buf',['buf',['../structmessage.html#ae39c7ead60245755a62c4aefcb0ea53e',1,'message']]]
];
