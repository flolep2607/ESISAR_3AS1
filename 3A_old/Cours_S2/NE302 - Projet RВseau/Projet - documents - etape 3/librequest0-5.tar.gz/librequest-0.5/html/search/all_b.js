var searchData=
[
  ['s_5fclient',['s_client',['../structs__client.html',1,'']]],
  ['s_5ffield',['s_field',['../structs__field.html',1,'']]],
  ['search',['search',['../structs__field.html#aad4b53dc2fef51a522ec724c45532afb',1,'s_field']]],
  ['sendbuffer',['sendBuffer',['../socket_8c.html#a49c52e8053164e9d140457af9d0df26c',1,'socket.c']]],
  ['sendreponse',['sendReponse',['../socket_8c.html#acd23356e16868a36c3f8361edb240a24',1,'socket.c']]],
  ['sendrequest',['sendRequest',['../socket_8c.html#ac7ba27f53966826f2e5ea5190fbe1705',1,'sendRequest(int i):&#160;socket.c'],['../socket_8c.html#adf0bc812ec61b3236f3968d05a2bd93a',1,'sendRequest(i):&#160;socket.c']]],
  ['shutdown',['SHUTDOWN',['../socket_8c.html#a663646f2d16be375255c4938b12d2033a7690b021f467450541d8d89123429d40',1,'socket.c']]],
  ['shutdown_5fafter_5fwrite',['SHUTDOWN_AFTER_WRITE',['../socket_8c.html#a663646f2d16be375255c4938b12d2033af7bbc7d1baece19624f507fab2281931',1,'socket.c']]],
  ['shutdownsocket',['shutdownSocket',['../socket_8c.html#a9f08a2a76d27006fb07d8ca1d4003c56',1,'socket.c']]],
  ['socket_2ec',['socket.c',['../socket_8c.html',1,'']]],
  ['state',['state',['../structs__client.html#a97bb33d47070233757d0ade6f83b8c82',1,'s_client::state()'],['../socket_8c.html#a47b936e7004e9cfa6c34be66fb9b4fde',1,'state():&#160;socket.c']]]
];
