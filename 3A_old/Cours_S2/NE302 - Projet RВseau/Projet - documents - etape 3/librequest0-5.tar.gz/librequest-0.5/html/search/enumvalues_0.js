var searchData=
[
  ['getbody',['GETBODY',['../socket_8c.html#a663646f2d16be375255c4938b12d2033a1a4984c24f1e22416611e0a77b7353b5',1,'socket.c']]],
  ['getchunk',['GETCHUNK',['../socket_8c.html#a663646f2d16be375255c4938b12d2033a3a958d139e584b7b805d80e889477687',1,'socket.c']]]
];
