var searchData=
[
  ['shutdown',['SHUTDOWN',['../socket_8c.html#a663646f2d16be375255c4938b12d2033a7690b021f467450541d8d89123429d40',1,'socket.c']]],
  ['shutdown_5fafter_5fwrite',['SHUTDOWN_AFTER_WRITE',['../socket_8c.html#a663646f2d16be375255c4938b12d2033af7bbc7d1baece19624f507fab2281931',1,'socket.c']]]
];
