var searchData=
[
  ['maxclient',['MAXCLIENT',['../request_8h.html#ace6c609072c3b2eaca1e74b065d61dc4',1,'request.h']]],
  ['message',['message',['../structmessage.html',1,'']]]
];
