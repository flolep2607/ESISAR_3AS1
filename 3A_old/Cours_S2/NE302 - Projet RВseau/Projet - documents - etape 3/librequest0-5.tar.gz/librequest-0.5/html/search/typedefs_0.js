var searchData=
[
  ['client',['client',['../socket_8c.html#aa575c454926626a73d159e61d210f7b1',1,'socket.c']]]
];
