var searchData=
[
  ['writable',['WRITABLE',['../socket_8c.html#a663646f2d16be375255c4938b12d2033a1a2fc96dac53bcd1adf6a1f1471a568c',1,'socket.c']]]
];
