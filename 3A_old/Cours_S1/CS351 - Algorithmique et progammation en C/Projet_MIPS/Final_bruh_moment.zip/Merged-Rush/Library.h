#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
/* Librairy standard à inclure dans tous les autres fichiers */