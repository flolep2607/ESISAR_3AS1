---
title: CS351@ Esisar -- MIPS Emulator Developer Documentation
subtitle: Step 2, 2021-2022 
author: Rougé Jean - Patard Gauthier
papersize: a4
geometry: margin=1.5cm
fontsize: 12pt
lang: fr
---


# Structure of the code
* Compile_Module.[c|h] : useful functions to input/output files in hex format
* Memory_Module.[c|h] : everything from memory management to read and write and display memory
* Execution_Module.[c|h] : functions to execute instruction and emulate a MIPS processor behavior.
* main.c : ...

# Encoding choices


For the Compile module, I used a struct to create an array of information for each instructions. I chose a struct because it was easier to deal with than a matrix.

For the Memory module, I used a chained list to implement memory because it would take less space. As our emulator will probably use very little memory, we made a compromise by only having in a chained list blocks that have at least one slot containning a value different from zero.

To describe CPU Structure, I made a strcuture for the the CPU internal registres, this is not really usefull it just makes things a little clearer; and I stored every other registre in an array of 32 bits integers.

# Emulator Structure


We thought of structuring our code that way:

* First, the main function takes care of filename, argument, etc... ; putting everything in place for other modules 
* Then it calls our Compile module which translate our instructions into machine code and output it in a .hex file as well as putting it into our emulator memory
* Third, the Execution module is called wich execute our code, all the memory acces are done via function in the Memory module but are called by the Execution processor
* Finally the main function call on last time the Memory module to output registres states in a file and free the Memory.

More details will be found in the code itself under the form of commentaries.

# Known bugs/undef behavior 
* Struggled to read user input in interractive mode, sometimes, you need to press enter 2 times, basically dealing with line feed (\\n) was a pain.


