#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

#ifndef UTILS
#define UTILS
#include "utils.h"
#endif

// #define max_memory 0xFFFFFFFF
#define max_memory 0xFF