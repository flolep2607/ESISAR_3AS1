#include "default.h"
#include "registre.h"
#include "memory.h"
#include "utils.h"

void execute_instruction(uint32_t instruction, register_pc *registers,memory* ram);